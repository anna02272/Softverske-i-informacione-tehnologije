
import java.util.*;

/**
 * @author Sinisa Nikolic
 */
public class KursnaLista {

    /**
     * Default constructor
     */
    public KursnaLista() {
    }

    /**
     * 
     */
    protected long id;

    /**
     * 
     */
    protected Date datum;

    /**
     * 
     */
    protected Set<VrednostValute> vrednostiValuta;

    /**
     * 
     */
    protected Set<VrednostValute> vrednostiValuta;

}