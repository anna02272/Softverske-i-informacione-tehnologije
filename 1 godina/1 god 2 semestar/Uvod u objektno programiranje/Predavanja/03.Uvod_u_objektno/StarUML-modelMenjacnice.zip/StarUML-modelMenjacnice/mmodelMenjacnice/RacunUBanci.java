
import java.util.*;

/**
 * @author Sinisa Nikolic
 */
public class RacunUBanci {

    /**
     * Default constructor
     */
    public RacunUBanci() {
    }

    /**
     * 
     */
    protected int sifraRacuna;

    /**
     * 
     */
    protected double stanje;

    /**
     * 
     */
    protected Klijent k;

    /**
     * 
     */
    protected Klijent k;

    /**
     * @param zaUplatu 
     * @return
     */
    public void uplatiNovac(double zaUplatu) {
        // TODO implement here
        return null;
    }

    /**
     * @param zaPodizanje 
     * @return
     */
    public boolean skiniNovac(double zaPodizanje) {
        // TODO implement here
        return false;
    }

}