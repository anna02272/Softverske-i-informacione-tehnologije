
import java.util.*;

/**
 * @author Sinisa Nikolic
 */
public class VrednostValute {

    /**
     * Default constructor
     */
    public VrednostValute() {
    }

    /**
     * 
     */
    protected KursnaLista kl;

    /**
     * 
     */
    protected Valuta val;

    /**
     * 
     */
    protected double kupovniKurs;

    /**
     * 
     */
    protected double prodajniKurs;

    /**
     * 
     */
    protected KursnaLista kl;

    /**
     * 
     */
    protected Valuta val;

}