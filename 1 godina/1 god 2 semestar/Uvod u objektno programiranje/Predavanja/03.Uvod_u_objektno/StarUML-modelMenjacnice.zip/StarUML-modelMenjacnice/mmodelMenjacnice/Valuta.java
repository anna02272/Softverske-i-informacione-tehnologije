
import java.util.*;

/**
 * @author Sinisa Nikolic
 */
public class Valuta {

    /**
     * Default constructor
     */
    public Valuta() {
    }

    /**
     * 
     */
    protected String oznakaValute;

    /**
     * 
     */
    protected String nazivValute;

    /**
     * 
     */
    protected Set<VrednostValute> vrednostiValuta;

    /**
     * 
     */
    protected Set<VrednostValute> vrednostiValuta;

}