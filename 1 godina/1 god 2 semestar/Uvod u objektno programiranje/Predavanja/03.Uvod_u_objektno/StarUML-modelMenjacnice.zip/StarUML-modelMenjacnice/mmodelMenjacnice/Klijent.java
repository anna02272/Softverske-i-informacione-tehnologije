
import java.util.*;

/**
 * @author Sinisa Nikolic
 */
public class Klijent {

    /**
     * Default constructor
     */
    public Klijent() {
    }

    /**
     * 
     */
    protected String JMBG;

    /**
     * 
     */
    protected String ImeIPrezime;

    /**
     * 
     */
    protected String adresa;

}