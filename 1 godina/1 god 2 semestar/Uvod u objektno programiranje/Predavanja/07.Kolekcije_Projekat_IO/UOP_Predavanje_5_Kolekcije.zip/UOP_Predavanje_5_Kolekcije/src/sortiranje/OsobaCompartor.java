package sortiranje;

import java.util.Comparator;

public class OsobaCompartor implements Comparator<Osoba>{
	@Override
	public int compare(Osoba o1, Osoba o2) {
		if(o1.getPlata()>o2.getPlata()) {
			return 1;
		}else if (o1.getPlata()<o2.getPlata()) {
			return -1;
		}
		return 0;
	}
}
