package kolekcije.map;

import java.util.*;

public class MyTreeMap {
	
	public static void main(String args[]) {
		
		TreeMap<String, String> treeMap = new TreeMap<>();
		
		treeMap.put("name", "Jody");
		treeMap.put("id", "123");
		treeMap.put("address", "Manila");
		treeMap.put("attribute1", "value1");
		
		for (String string : treeMap.keySet()) {
			System.out.println(string + "\t" + treeMap.get(string));
		}	
	}
}
