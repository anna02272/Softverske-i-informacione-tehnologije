package sortiranje;

import java.io.Serializable;
import java.util.Comparator;

public class OsobaNew implements Comparable<OsobaNew>, Comparator<OsobaNew>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String ime;
	private String prezime;
	private double plata;
	
	@Override
	public int compareTo(OsobaNew o) {
		return o.ime.compareTo(this.ime);
	}

	@Override
	public int compare(OsobaNew arg0, OsobaNew arg1) {
		if(arg0.plata>arg1.plata) {
			return 1;
		}else if(arg0.plata<arg1.plata) {
			return -1;
		}
		return 0;
	}
}
