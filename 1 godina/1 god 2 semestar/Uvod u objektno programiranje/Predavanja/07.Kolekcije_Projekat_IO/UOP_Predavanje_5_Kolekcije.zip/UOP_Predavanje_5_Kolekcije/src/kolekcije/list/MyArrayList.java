package kolekcije.list;

import java.util.ArrayList;
import java.util.Iterator;

public class MyArrayList {
	
	public static void main(String args[ ]) {
	
		ArrayList alist = new ArrayList( );
		
		alist.add("Two");
		alist.add(0, "One");
		alist.add("Three");
		
		System.out.println(alist.get(0));
		System.out.println(alist.get(1));
		System.out.println(alist.get(2));
		//dozvoljeno
		alist.add(5.3);
		System.out.println(alist.get(3));
//		double a = (double) alist.get(3);
//		double a = (double) alist.get(0);
		
		//tipizirane kolekcije
		System.out.println("---------------------------------------");
		ArrayList<String> alistTipizirana = new ArrayList<>();
		
		alistTipizirana.add("Two");
		alist.add(0, "One");
		alistTipizirana.add("Three");
		
		//nije dozvoljeno
//		alistTipizirana.add(5.3);
		
		System.out.println(alistTipizirana.get(0));
		System.out.println(alistTipizirana.get(1));
		System.out.println(alistTipizirana.get(2));
		
		System.out.println("---------------------------------------");
		Iterator<String> iterator = alistTipizirana.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
}

