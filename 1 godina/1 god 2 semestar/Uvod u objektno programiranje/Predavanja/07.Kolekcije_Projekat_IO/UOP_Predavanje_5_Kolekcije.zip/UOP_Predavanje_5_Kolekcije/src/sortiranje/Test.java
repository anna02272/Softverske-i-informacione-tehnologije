package sortiranje;

import java.util.ArrayList;
import java.util.Collections;

public class Test {
	
	public static void main(String [] args) {
		Osoba o1 = new Osoba("Sima", "Simic");
		Osoba o2 = new Osoba("Pera", "Peric");
		Osoba o3 = new Osoba("Nikola", "Nikolic");
		
		ArrayList<Osoba> osobe = new ArrayList<>();
		osobe.add(o1);
		osobe.add(o2);
		osobe.add(o3);
		
		System.out.println("nesortirano-----------------");
		for (Osoba osoba : osobe) {
			System.out.println(osoba);
		}
		
		Collections.sort(osobe);
		
		System.out.println("Sortirano compareTo iz Osobe-----------------");
		for (Osoba osoba : osobe) {
			System.out.println(osoba);
		}
		
		osobe = new ArrayList<>();
		o1.setPlata(123.34);
		osobe.add(o1);
		o2.setPlata(50);
		osobe.add(o2);
		o3.setPlata(140);
		osobe.add(o3);
		
		Collections.sort(osobe, new Osoba());
		System.out.println("Sortirano compare iz Osobe-----------------");
		for (Osoba osoba : osobe) {
			System.out.println(osoba);
		}
		
		Collections.sort(osobe, new OsobaCompartor());
		System.out.println("Sortirano compare iz OsobaCompartor-----------------");
		for (Osoba osoba : osobe) {
			System.out.println(osoba);
		}
	}
}
