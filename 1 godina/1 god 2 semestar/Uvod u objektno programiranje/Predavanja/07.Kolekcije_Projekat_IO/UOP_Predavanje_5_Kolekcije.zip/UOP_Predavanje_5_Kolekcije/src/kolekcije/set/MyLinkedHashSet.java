package kolekcije.set;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class MyLinkedHashSet {

	public static void main(String args[ ]) {
		
		LinkedHashSet lhs = new LinkedHashSet();
		
		lhs.add("One");
		lhs.add(new Integer(1));
		lhs.add("Two");
		lhs.add("Three");
//		lhs.add(1, "Tekst");
			
		Object array[] = lhs.toArray( );
		
		for(int x=0; x<lhs.size(); x++) {
		   System.out.println(array[x]);	
		}
		System.out.println("---------------------------------------");
		
		LinkedHashSet<String> lhsT = new LinkedHashSet<>();
		lhsT.add("Four");
		lhsT.add("One");
		lhsT.add("Zero");
		lhsT.add("Two");
		lhsT.add("Three");
		lhsT.add("Zero");
//		lhsT.add(new Integer(1));
		
		for (String string : lhsT) {
			System.out.println(string);
		}
		System.out.println("---------------------------------------");
		
		System.out.println("\npreko iteratora -------------");
		Iterator<String> iteratorT = lhsT.iterator();
		while(iteratorT.hasNext( )) {
		   System.out.println(iteratorT.next());
		}
	}			
}

