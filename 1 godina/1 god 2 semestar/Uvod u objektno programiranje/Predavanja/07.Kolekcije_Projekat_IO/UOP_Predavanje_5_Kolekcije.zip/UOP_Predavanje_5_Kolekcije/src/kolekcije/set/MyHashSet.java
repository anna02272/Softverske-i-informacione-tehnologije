package kolekcije.set;

import java.util.HashSet;
import java.util.Iterator;

public class MyHashSet {
	
	public static void main(String args[ ]) {
		
		HashSet hash = new HashSet();
		
		hash.add("b");
		hash.add("a");
		hash.add(new Integer(3));
		hash.add(new Integer(5));
		hash.add(new Integer(55));
		hash.add("c");
		hash.add("a");
		hash.add("d");
		
				
		Iterator iterator = hash.iterator( );
		
		while(iterator.hasNext( )) {
		   System.out.println(iterator.next( ));
		}
		
		System.out.println("\npreko niza -------------");
		for (Object ob : hash.toArray()) {
			System.out.println(ob);
		}
		
		HashSet<String> hashTipiziran = new HashSet<>();
		
		hashTipiziran.add("a");
		hashTipiziran.add("b");
		hashTipiziran.add("pera");
		hashTipiziran.add("c");
		hashTipiziran.add("d");
		hashTipiziran.add("sima");
//		hashTipiziran.add(new Integer(1));
		Iterator<String> iteratorT = hashTipiziran.iterator();
		System.out.println("\npreko iteratora -------------");
		while(iteratorT.hasNext( )) {
		   System.out.println(iteratorT.next());
		}
		System.out.println("\nforeach petlja -------------");
		for (String string : hashTipiziran) {
			System.out.println(string);
		}
	}
}

