package kolekcije.set;

import java.util.TreeSet;

import sortiranje.DuzinaStringaCompartor;
import sortiranje.Osoba;
import sortiranje.OsobaCompartor;

import java.util.ArrayList;
import java.util.Iterator;

public class MyTreeSet {
	
	public static void main(String args[ ]) {
	
		TreeSet<String> tree = new TreeSet<>(new DuzinaStringaCompartor());
				
		tree.add("Jody");
		tree.add("Remiel");
		tree.add("Reggie");
		tree.add("Philippe");
		tree.add("Eddie");
		
		//zasto nedostaje Reggie???
		
		System.out.println("\nPoredak preko komaratora-------");
		Iterator<String> iteratorT = tree.iterator();
		while(iteratorT.hasNext( )) {
		   System.out.println(iteratorT.next());
		}
		System.out.println("\nPoredak preko niza-------");
		for (String string : tree) {
			System.out.println(string);
		}
		
		Osoba o1 = new Osoba("Sima", "Simic", 100);
		Osoba o2 = new Osoba("Pera", "Peric", 30);
		Osoba o3 = new Osoba("Nikola", "Nikolic", 55);
		
		System.out.println("\nPoredak preko komaratora Comparator-------");
		TreeSet<Osoba> treeOsobaComparator = new TreeSet<Osoba>(new OsobaCompartor());
		
		treeOsobaComparator.add(o1);
		treeOsobaComparator.add(o2);
		treeOsobaComparator.add(o3);
		
		Iterator<Osoba> iteratorTO = treeOsobaComparator.iterator();
		System.out.println("preko iteratora -------------");
		while(iteratorTO.hasNext( )) {
		   System.out.println(iteratorTO.next());
		}
		
		System.out.println("\nPoredak preko komaratora Comparable-------");
		TreeSet<Osoba> treeOsobaComparable = new TreeSet<Osoba>();
		
		treeOsobaComparable.add(o1);
		treeOsobaComparable.add(o2);
		treeOsobaComparable.add(o3);
		
		Iterator<Osoba> iteratorTO2 = treeOsobaComparable.iterator();
		System.out.println("preko iteratora -------------");
		while(iteratorTO2.hasNext( )) {
		   System.out.println(iteratorTO2.next());
		}
		
	}		
}

