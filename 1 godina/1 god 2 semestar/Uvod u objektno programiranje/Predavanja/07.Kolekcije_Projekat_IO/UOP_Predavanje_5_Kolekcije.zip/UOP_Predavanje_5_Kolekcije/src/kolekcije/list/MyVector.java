package kolekcije.list;

import java.util.Vector; 

public class MyVector {

	public static void main(String args[ ]) {
		
		Vector vecky = new Vector();
		
		vecky.add(new Integer(1));
		vecky.add(new Integer(2));
		vecky.add(new Integer(3));
		vecky.add(2, "tekst");
		
		for(int x=0; x<vecky.size(); x++) {
		   System.out.println(vecky.get(x));
		}
		
		System.out.println("---------------------------------------");
		
		Vector<Integer> veckyTipiziran = new Vector<>();
		
		veckyTipiziran.add(new Integer(1));
		veckyTipiziran.add(new Integer(2));
		veckyTipiziran.add(new Integer(3));
//		veckyTipiziran.add(2, "tekst");
		
		for(int x=0; x<veckyTipiziran.size(); x++) {
		   System.out.println(veckyTipiziran.get(x));
		}
	}	
}

