package kolekcije.map;

import java.util.Hashtable;

public class MyHashtable {
	
	public static void main(String args[ ]) {
		
	    Hashtable<String, String> table = new Hashtable<String, String>();
		table.put("name", "Jody");
		table.put("id", "123");
		table.put("address", new String("Manila"));
     	
		for (String key : table.keySet()) {
			System.out.println(key + "\t" + table.get(key));
		}
		System.out.println("---------------------------------------");
		
//		System.out.println("Table of Contents:" + table);
	}
}

