package kolekcije.list;

import java.util.Iterator;
import java.util.LinkedList;

public class MyLinkedList {

	public static void main(String args[ ]) {
		
		LinkedList link = new LinkedList(); 
		
		link.add(new Double(2.0));
		link.addFirst(new Double(1.0));
		link.addLast(new Double(3.0));
		link.add(2, "tekst");
	
		Object array[] = link.toArray();
		
		for(int x=0; x<array.length; x++) {
		   System.out.println(array[x]);
		}
		System.out.println("---------------------------------------");
		
		LinkedList<Double> linkTipizirana = new LinkedList<>(); 
		
		linkTipizirana.add(new Double(2.0));
		linkTipizirana.addLast(new Double(3.0));
		linkTipizirana.addFirst(new Double(1.0));
//		linkTipizirana.add(2, "tekst");
		
		for (Double d : linkTipizirana) {
			System.out.println(d);
		}
		System.out.println("---------------------------------------");
		Iterator<Double> iterator = linkTipizirana.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		System.out.println("---------------------------------------");
		
	}
}

