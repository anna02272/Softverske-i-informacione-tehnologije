package kolekcije.map;

import java.util.*;

public class MyLinkedHashMap {
	
	public static void main(String args[ ]) {
		LinkedHashMap<String,String> myMap = new LinkedHashMap<>();
		
		myMap.put("name", "Jody");
		myMap.put("id", "123");
		myMap.put("address", "Manila");
		myMap.put("type", "Savings");
		myMap.put("attribute1", "value1");
		
		for (String string : myMap.keySet()) {
			System.out.println(string + "\t" + myMap.get(string));
		}	
	}
}

