package kolekcije.map;

import java.util.HashMap;
import java.util.Iterator;

public class MyHashMap {
	
	public static void main(String args[ ]) {
		
		HashMap<String,String> map = new HashMap<String,String>();		
		map.put("name", "Jody");
		map.put("id", "123");
		map.put("address", "Manila");
		
		System.out.println("Pristup odredjenim ---------------------------------------");
		System.out.println("Name: " + map.get("name"));
		System.out.println("ID: " + map.get("id"));
		System.out.println("Address: " + map.get("address"));
		
		System.out.println("Ispis svih---------------------------------------");
		map.put("address", "Manila234");
		for (String key : map.keySet()) {
			System.out.println(key + "\t" + map.get(key));
		}
//		System.out.println("---------------------------------------");
//		
//		System.out.println(map);
//		
//		System.out.println("---------------------------------------");
//		Iterator<String> iterator = map.keySet().iterator();
//		while(iterator.hasNext()) {
//			System.out.println(map.get(iterator.next()));
//		}
//		
//		System.out.println("---------------------------------------");
//		for(String ob : map.values()) {
//			System.out.println(ob);
//		}
	}
}

