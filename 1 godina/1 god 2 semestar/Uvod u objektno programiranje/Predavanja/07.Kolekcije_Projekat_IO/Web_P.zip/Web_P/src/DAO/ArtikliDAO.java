package DAO;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import model.Artikal;
import model.Kompzicija;
import model.MuzickiCD;
import util.FileUtils;

public class ArtikliDAO {

	public static ArrayList<Artikal> loadMuzickiCDFromFile() {
		ArrayList<Artikal> artikli = new ArrayList<Artikal>();
		try (BufferedReader in = FileUtils.getReader("MuzickiCD")) {
			String line;
			while ((line = in.readLine()) != null) {
				MuzickiCD mCD = MuzickiCD.fromString(line);
				mCD.setKompozicije(loadKompzicijaFromFile(mCD.getId()));
				artikli.add(mCD);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return artikli;
	}
	
	private static ArrayList<Kompzicija> loadKompzicijaFromFile(int idMuzickiCD) {
		ArrayList<Kompzicija> kompozicije = new ArrayList<Kompzicija>();
		try (BufferedReader in = FileUtils.getReader("MuzickiCDKompozicije")) {
			String line;
			while ((line = in.readLine()) != null) {
				//30,14,Aerials,6.11
				int z = line.indexOf(",");
				int idMCD = Integer.parseInt(line.substring(0,z));
				if (idMCD==idMuzickiCD) {
					kompozicije.add(Kompzicija.fromFileString(line));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return kompozicije;
	}

	public static void saveMuzickiCDToFile(ArrayList<Artikal> list) {
		try (PrintWriter out = FileUtils.getPrintWriter("MuzickiCD")) {
			for (Artikal a : list) {
				out.println(a.toFileString());
			}
			saveKompozicijaToFile(list);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void saveKompozicijaToFile(ArrayList<Artikal> list) {
		try (PrintWriter out = FileUtils.getPrintWriter("MuzickiCDKompozicije")) {
			for (Artikal a : list) {
				if(a instanceof MuzickiCD){
					MuzickiCD mCD = (MuzickiCD) a;
					for (Kompzicija k : mCD.getKompozicije()) {
						out.println(mCD.getId() + "," + k.toFileString());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
