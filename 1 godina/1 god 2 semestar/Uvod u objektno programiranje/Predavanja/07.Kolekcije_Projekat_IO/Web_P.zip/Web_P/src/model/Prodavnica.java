package model;

import java.util.ArrayList;

public class Prodavnica {
	
	private ArrayList<Artikal> artikli;

	public Prodavnica(ArrayList<Artikal> artikli) {
		this.artikli = artikli;
	}

	public void printArtikli() {
		for (Artikal artikl : artikli) {
			System.out.println(artikl.toString());				
		}
	}
	
	public void printByIDArtikli(int id) {
		for (Artikal artikl : artikli) {
			if(artikl.getId()==id){
				System.out.println(artikl.toString());
				if(artikl instanceof MuzickiCD)
					System.out.println(((MuzickiCD)artikl).toStringAllKompozicije());
				break;
			}			
		}
	}
	
	public void addArtikl(Artikal a) {
		artikli.add(a);
	}

	public ArrayList<Artikal> getArtikli() {
		return artikli;
	}
}
