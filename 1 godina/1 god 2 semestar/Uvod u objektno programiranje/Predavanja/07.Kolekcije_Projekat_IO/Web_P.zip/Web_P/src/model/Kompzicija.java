package model;

import util.StringUtils;

public class Kompzicija {
	
	private int redBr;
	private String naziv;
	private double trajanje;
	
	public Kompzicija(int redBr, String naziv, double trajanje) {
		super();
		this.redBr = redBr;
		this.naziv = naziv;
		this.trajanje = trajanje;
	}
	public static Kompzicija fromFileString(String str) {
		//30,14,Aerials,6.11
		String parts [] = str.split(",");
		int redBr = Integer.parseInt(parts[1]);
		String naziv = parts[2];
		double trajanje = Double.parseDouble(parts[3]);
		return new Kompzicija(redBr, naziv, trajanje);
	}
	
	public String toFileString() {
		//nedostaje samo id Muzickog CD a to cemo naknadno dodati
		return redBr + "," + StringUtils.clean(naziv) + "," + trajanje;
	}
	
	@Override
	public String toString() {
		return redBr + ". " + StringUtils.clean(naziv) + " traje " + trajanje + " minuta";
	}
	
	public int getRedBr() {
		return redBr;
	}
	public void setRedBr(int redBr) {
		this.redBr = redBr;
	}
	public String getNaziv() {
		return naziv;
	}
	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}
	public double getTrajanje() {
		return trajanje;
	}
	public void setTrajanje(double trajanje) {
		this.trajanje = trajanje;
	}
}
