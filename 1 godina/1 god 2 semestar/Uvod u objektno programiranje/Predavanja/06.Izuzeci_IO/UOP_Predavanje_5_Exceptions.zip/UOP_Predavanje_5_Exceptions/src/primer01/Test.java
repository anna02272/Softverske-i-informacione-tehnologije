package primer01;

import java.io.FileNotFoundException;
import java.io.IOException;


public class Test {

	public static void test2() {
		try {
			Datoteka.ucitavanjePodatakaCVS();
		}
//		catch (IOException e) {
//			System.out.println("greska pri radu sa fajlovima - ne postoji fajl ili ne moze da se cita/pise fajl");
//		}
		catch (FileNotFoundException e) {
			System.out.println("Fajl ne postoji");
		}
		catch (IOException e) {
			System.out.println("greska pri citanju/pisanju iz fajla");
		}
	}
	
	public static int test3() throws IzuzetakNeodgovarajuciFormatBroja{
		String tekst = "NIJE BROJ NEGO TEKST";
		
		if(Utility.isInteger(tekst)==false)
			throw new IzuzetakNeodgovarajuciFormatBroja(tekst);
		
		return Integer.parseInt(tekst);
	}
	
	public static void main(String[] args) throws Exception{

		boolean greska = false;
		int broj=0;

		try {
			//verzija 1 - Greska pri konverziji teksta u broj
//			broj = Integer.parseInt("NIJE BROJ NEGO TEKST");
			
			//verzija 2 - Greska metoda je pozvana u nedozvoljenom trunutku 
//			Utility.sc.close();
//			System.out.println("Unesite broj");
//			broj = Utility.ocitajCeoBroj();
			
			//verzija 3 - Greska pri konverziji objekata 
//			Object obj = new Student("3,E1 03/2013,Trajković,Nebojša,Inđija");
//			Predmet b = (Predmet) obj;
			
		}
		catch (NumberFormatException ex){
			System.out.println("greska pri parsiranju teksta u broj");
			greska=true;
		}
		catch (IllegalStateException ex){
			System.out.println("greska pri radu sa skenerom");
			greska=true;
		}
		catch (ClassCastException ex) {
			System.out.println("Zabranjena konverzija");
			greska=true;
		}
		catch (Exception ex){
			System.out.println("greska");
			ex.printStackTrace();
			greska=true;
		} 
		finally {
			System.out.println("Obavezan deo try/catch");
			if(greska==true){
				if(Utility.ocitajOdlukuOPotvrdi("nastaviti aplikaciju") == 'N')
					return;
			}
		}
		
		System.out.println("Nastavak aplikacije");
		
//		test2();
		
		try {
//			broj = test3();
			
		} catch (IzuzetakNeodgovarajuciFormatBroja e) {
			System.out.println("Moj izuzetak IzuzetakNeodgovarajuciFormatBroja");
			e.ispisIzuzetak();
			e.printStackTrace();
		}
		 
		System.out.println("Kraj aplikacije");
	}

}
