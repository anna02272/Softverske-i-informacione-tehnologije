package primer01;

public class IzuzetakNeodgovarajuciFormatBroja extends NumberFormatException{

	String problematicanTekst;
	
	public IzuzetakNeodgovarajuciFormatBroja(String problematicanTekst) {
		super();
		this.problematicanTekst = problematicanTekst;
	}

	public void ispisIzuzetak (){
		System.out.println("Greska je nastala u delu teksta " + problematicanTekst);
	}
}
