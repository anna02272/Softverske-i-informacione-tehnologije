package primer01;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

//klasa koja ima dve staticke metode za rad sa CSV datotekom - ucitavanje i snimanje
public class Datoteka {
	
	/**
	 * METODE ZA UCITAVANJE I SNIMANJE PODATAKA
	 * 
	 ****/
	
	public static void ucitavanjePodatakaCVS() throws FileNotFoundException, IOException{

		
		String sP = System.getProperty("file.separator");
		
		File studenti = new File("."+sP+"materijali"+sP+"studentiFajlNePostoji.csv"); 
//		File studenti = new File("."+sP+"materijali"+sP+"studenti.csv");

		BufferedReader in = new BufferedReader(
				new FileReader(studenti));
		
		//workaround for UTF-8 files and BOM marker
		//BOM (byte order mark) marker may appear on the beginning of the file
		//BOM can signal which of several Unicode encodings (8-bit, 16-bit, 32-bit) that text is encoded as
		
		in.mark(1); //zapamti trenutnu poziciju u fajlu da mozes kasnije da se vratis na nju
		if(in.read()!='\ufeff'){
			in.reset();
		}
		
		String s2;
		while((s2 = in.readLine()) != null) {
			System.out.println(s2);
		}
		in.close();
	}
}
