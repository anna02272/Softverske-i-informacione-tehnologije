package primer02;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class IO02 {
	
	public static void copyFile(String source, String dest) {
		byte[] buffer = new byte[1024];
		try {
			FileInputStream fin = new FileInputStream(source);
			FileOutputStream fout = new FileOutputStream(dest);
			while (fin.read(buffer, 0, 1024) != -1) {
				fout.write(buffer, 0, 1024);
			}
			fin.close();
			fout.close();
		} catch (Exception e) {
			System.out.println("Doslo je do greske.");
			e.printStackTrace();
		} 
	}

	public static void filterTest(String source) {
		try (DataOutputStream dout = 
				new DataOutputStream(
						new BufferedOutputStream(
								new FileOutputStream(source)))) {
			dout.writeInt(5);
			dout.writeDouble(2.4);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try (DataInputStream di = 
				new DataInputStream(new 
						BufferedInputStream(
								new FileInputStream(source)))) {
			int ceoBroj = di.readInt();
			double realanBroj = di.readDouble();
			System.out.println(ceoBroj+"\t"+realanBroj);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		String sP = System.getProperty("file.separator");
		
		String source = "."+sP+"materijali"+sP+"Desert.jpg";
		String dest = "."+sP+"materijali"+sP+"DesertKopija.jpg";

		copyFile(source, dest);
		
		String binarni = "."+sP+"materijali"+sP+"binarni.dat";
//		filterTest(binarni);
		
		System.out.println("kraj");
	}

}
