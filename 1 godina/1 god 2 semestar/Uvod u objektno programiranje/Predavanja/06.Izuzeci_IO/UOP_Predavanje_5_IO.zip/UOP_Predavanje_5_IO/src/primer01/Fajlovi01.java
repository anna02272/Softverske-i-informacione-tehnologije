package primer01;

import java.io.File;
import java.io.IOException;

public class Fajlovi01 {

	static void izlistajSadrzajFolera(String putanja){
		
		//kreiranje File objekta koji reprezentuje current folder
		File current = new File(putanja);
		//Prikaz absolutne putanje ovog foldera
		System.out.println(current.getAbsolutePath());
		//provera da li folder
		if(current.isDirectory()){
			//prikaz sadrzaja ovog foldera
			for (File file : current.listFiles()) {
				if(file.isDirectory())
					System.out.println(file.getName() + ", folder");
				else if(file.isFile()) //da li je potrebna ova provera?
					System.out.println(file.getName() + ", size (bytes): " + file.length());
			}
		}
	}
	
	 
	public static void main(String[] args) throws IOException {
		
		String putanja = ".";
		izlistajSadrzajFolera(putanja);
		
		//separator putanje se pribavlja iz OS
		String sP = System.getProperty("file.separator");
		System.out.println("\nSeparator je "+sP);
		
		//TODO prikazati sadrzaj foldera materijali
		izlistajSadrzajFolera("."+sP+"materijali");
	}
}
