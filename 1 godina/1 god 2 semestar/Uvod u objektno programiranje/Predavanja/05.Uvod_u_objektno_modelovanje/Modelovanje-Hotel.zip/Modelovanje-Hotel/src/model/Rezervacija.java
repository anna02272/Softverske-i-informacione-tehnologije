package model;

import java.util.Date;

import utils.PomocnaKlasa;

public class Rezervacija {

	protected int id;
	protected Soba soba;
	protected Date ulazak;
	protected Date izlazak;
	protected String imeIPrezime;

	public Rezervacija(int id, Soba soba, Date ulazak, Date izlazak, String imeIPrezime) {
		this.id = id;
		this.soba = soba;
		this.ulazak = ulazak;
		this.izlazak = izlazak;
		this.imeIPrezime = imeIPrezime;
	}

	@Override
	public String toString() {
		return "Rezervacija [id=" + id + ", ulazak=" + PomocnaKlasa.sdf.format(ulazak) 
			+ ", izlazak=" + PomocnaKlasa.sdf.format(izlazak) 
			+ ", imeIPrezime=" + imeIPrezime + ", soba=" + soba.getId() 
			+ ", ukupna vrednost rezervacije=" +getUkupnaVrednost() + "]";
	}
	public String toFormatedString() {
		return String.format("|%4d|%20s|%20s|%-20s|%7d|%27.2f|\n", id, PomocnaKlasa.sdf.format(ulazak),
				PomocnaKlasa.sdf.format(izlazak), imeIPrezime, soba.getId(), getUkupnaVrednost());
	}
	
	
	public double getUkupnaVrednost() {
		long kraj = izlazak.getTime();
		long pocetak = ulazak.getTime();
		long razlika = kraj - pocetak;
		int razlikaInt = (int)(razlika/(1000 * 60 * 60 * 24));
		
		return (double)(razlikaInt * soba.getCenaNocenja());
	}

	public boolean rezervacijaPripadaOpesegu(Date donjaGranica, Date gornjaGranica){
		boolean pripada = false;
		// |donjaGranica| -ulazak- -izlazak- |goranjGranica|
		pripada = donjaGranica.before(ulazak) && gornjaGranica.after(izlazak); //u celosti
		return pripada;
	}
	
	public boolean rezervacijaDelimicnoPripadaOpesegu(Date donjaGranica, Date gornjaGranica){
		boolean pripada = false;
		// |donjaGranica| -ulazak- |gornjaGranica|  -izlazak-
		pripada = pripada || (donjaGranica.before(ulazak) && ulazak.before(gornjaGranica));		
		// -ulazak- |donjaGranica|  -izlazak- |gornjaGranica|
		pripada = pripada || (donjaGranica.before(izlazak) && izlazak.before(gornjaGranica)); 
		return pripada;
	}
	
	public boolean rezervacijaObuhvataOpseg(Date donjaGranica, Date gornjaGranica){
		boolean pripada = false;
		// -ulazak- |donjaGranica| |goranjGranica| -izlazak- 
		pripada = ulazak.before(donjaGranica) && izlazak.after(gornjaGranica); //u celosti
		return pripada;
	}
	
	public boolean rezervacijaDelimicnoObuhvataOpeseg(Date donjaGranica, Date gornjaGranica){
		boolean pripada = false;
		// -ulazak- |donjaGranica|  -izlazak-
		pripada |= (ulazak.before(donjaGranica) && donjaGranica.before(izlazak));		
		// -ulazak- |gornjaGranica|  -izlazak-
		pripada |= (ulazak.before(gornjaGranica) && gornjaGranica.before(izlazak));
		return pripada;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Rezervacija other = (Rezervacija) obj;
		if (id != other.id)
			return false;
		return true;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Soba getSoba() {
		return soba;
	}

	public void setSoba(Soba soba) {
		this.soba = soba;
	}

	public Date getUlazak() {
		return ulazak;
	}

	public void setUlazak(Date ulazak) {
		this.ulazak = ulazak;
	}

	public Date getIzlazak() {
		return izlazak;
	}

	public void setIzlazak(Date izlazak) {
		this.izlazak = izlazak;
	}

	public String getImeIPrezime() {
		return imeIPrezime;
	}

	public void setImeIPrezime(String imeIPrezime) {
		this.imeIPrezime = imeIPrezime;
	}
}
