DROP SCHEMA IF EXISTS hotel;
CREATE SCHEMA hotel DEFAULT CHARACTER SET utf8;
USE hotel;

CREATE TABLE soba(
	id INT AUTO_INCREMENT,
	tip_sobe VARCHAR(30) NOT NULL,
	brojKreveta INT NOT NULL,
	cenaNocenja DOUBLE NOT NULL,
	PRIMARY KEY (id)
);

CREATE TABLE rezervacija(
	id INT AUTO_INCREMENT,
	id_sobe INT NOT NULL,
	ulazak DATETIME NOT NULL,
	izlazak DATETIME NOT NULL,
	imeIPrezime VARCHAR(30) NOT NULL,
	PRIMARY KEY (id),
	
	FOREIGN KEY (id_sobe) REFERENCES soba(id)
	    ON DELETE RESTRICT
);

INSERT INTO soba (id, tip_sobe, brojKreveta, cenaNocenja) VALUES (1,"Studio", 2, 2000.00);
INSERT INTO soba (id, tip_sobe, brojKreveta, cenaNocenja) VALUES (2,"Suite", 1, 2500.00);
INSERT INTO soba (id, tip_sobe, brojKreveta, cenaNocenja) VALUES (3,"Family room", 4, 3500.00);
INSERT INTO soba (id, tip_sobe, brojKreveta, cenaNocenja) VALUES (4,"Interconected rooms", 2, 2500.00);
INSERT INTO soba (id, tip_sobe, brojKreveta, cenaNocenja) VALUES (5,"Interconected rooms", 2, 2500);
INSERT INTO soba (id, tip_sobe, brojKreveta, cenaNocenja) VALUES (6,"Suite", 2, 3000.00);

INSERT INTO rezervacija (id, id_sobe, ulazak, izlazak, imeIPrezime) VALUES (1, 6, "2017-11-01 12:00:00", "2017-11-10 10:00:00", "Petar Petrovic");
INSERT INTO rezervacija (id, id_sobe, ulazak, izlazak, imeIPrezime) VALUES (2, 3, "2017-11-05 13:00:00", "2017-11-10 08:00:00", "Marko Markovic");
INSERT INTO rezervacija (id, id_sobe, ulazak, izlazak, imeIPrezime) VALUES (3, 6, "2017-11-19 03:00:00 ", "2017-11-22 03:00:00 ", "Jovan Jovanovic");
INSERT INTO rezervacija (id, id_sobe, ulazak, izlazak, imeIPrezime) VALUES (4, 3, "2017-11-10 12:30:00", "2017-11-20 07:00:00 ", "Petar Petrovic");
INSERT INTO rezervacija (id, id_sobe, ulazak, izlazak, imeIPrezime) VALUES (5, 4, "2017-11-10 12:00:00 ", "2017-12-02 08:00:00 ", "Marko Markovic");
INSERT INTO rezervacija (id, id_sobe, ulazak, izlazak, imeIPrezime) VALUES (6, 5, "2017-11-10 12:00:00", "2017-12-02 08:00:00", "Marko Markovic");