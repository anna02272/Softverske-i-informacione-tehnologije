package kos;

public class Igrac {

	int sifra;
	String imeIPrezime;
	Klub kl;
}
