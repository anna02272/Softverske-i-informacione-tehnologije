package kos;

public class Sudija {

	int sifra;
	String imeIPrezime;
	
}
