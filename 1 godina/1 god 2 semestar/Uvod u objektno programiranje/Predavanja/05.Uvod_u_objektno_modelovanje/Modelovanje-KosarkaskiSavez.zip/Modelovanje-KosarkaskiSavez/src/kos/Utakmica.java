package kos;

import java.util.ArrayList;

public class Utakmica {

	int sifra;
	String datumIVreme;
	Klub domacin;
	Klub gost;
	int koseviD;
	int koseviG;
	ArrayList<Sudija> sudije = new ArrayList<Sudija>();
	
}
