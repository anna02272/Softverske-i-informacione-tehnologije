package kos;

import java.util.ArrayList;

public class Klub {

	int sifra;
	String naziv;
	ArrayList<Igrac> sviIgraci = new ArrayList<Igrac>();
	
}
