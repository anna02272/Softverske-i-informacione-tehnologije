package model;

public class VrednostValute {

	private Valuta v;
	private double kupovniKurs;
	private double prodajniKurs;

	public VrednostValute() {

	}

	public VrednostValute(Valuta v, double kupovniKurs, double prodajniKurs) {
		this.v = v;
		this.kupovniKurs = kupovniKurs;
		this.prodajniKurs = prodajniKurs;
	}

	public Valuta getV() {
		return v;
	}

	public void setV(Valuta v) {
		this.v = v;
	}

	public double getKupovniKurs() {
		return kupovniKurs;
	}

	public void setKupovniKurs(double kupovniKurs) {
		this.kupovniKurs = kupovniKurs;
	}

	public double getProdajniKurs() {
		return prodajniKurs;
	}

	public void setProdajniKurs(double prodajniKurs) {
		this.prodajniKurs = prodajniKurs;
	}

	@Override
	public String toString() {
		return "Valuta " + v + " sa prodajnim " + prodajniKurs + " i kupovnim kursom " + kupovniKurs;
	}

	public String toFileRepresentation() {
		return v + ", " + kupovniKurs + ", " + prodajniKurs;
	}

}
