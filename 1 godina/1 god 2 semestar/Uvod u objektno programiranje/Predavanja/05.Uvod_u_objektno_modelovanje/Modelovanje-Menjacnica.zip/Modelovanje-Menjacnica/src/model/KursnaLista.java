package model;

import java.util.ArrayList;

public class KursnaLista {

	private String datum;
	private ArrayList<VrednostValute> vrednostiValute = new ArrayList<VrednostValute>();

	public KursnaLista() {

	}

	public KursnaLista(String datum) {
		this.datum = datum;
	}

	public KursnaLista(String datum, ArrayList<VrednostValute> vrednostiValute) {
		this.datum = datum;
		this.vrednostiValute = vrednostiValute;
	}

	public String getDatum() {
		return datum;
	}

	public void setDatum(String datum) {
		this.datum = datum;
	}

	public ArrayList<VrednostValute> getVrednostiValute() {
		return vrednostiValute;
	}

	public void setVrednostiValute(ArrayList<VrednostValute> vrednostiValute) {
		this.vrednostiValute = vrednostiValute;
	}

	@Override
	public String toString() {
		return "KursnaLista sa datumom " + datum;
	}

	public String toStringAll() {
		StringBuilder sb = new StringBuilder("Kursna lista na dan " + datum);

		if (vrednostiValute != null) {
			sb.append(" ima vrednosti valute\n");
			for (int i = 0; i < vrednostiValute.size(); i++) {
				sb.append("\t" + vrednostiValute.get(i).toString() + "\n");
			}
		}
		return sb.toString();
	}

	public String toFileRepresentation() {
		return datum;
	}

}
