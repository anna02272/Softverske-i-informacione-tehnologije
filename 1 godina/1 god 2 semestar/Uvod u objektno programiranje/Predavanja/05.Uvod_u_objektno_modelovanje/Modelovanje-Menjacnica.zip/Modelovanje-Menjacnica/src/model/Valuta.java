package model;

public class Valuta {

	private String oznaka;
	private String naziv;

	public Valuta() {

	}

	public Valuta(String oznaka, String naziv) {
		this.oznaka = oznaka;
		this.naziv = naziv;
	}

	public String getOznaka() {
		return oznaka;
	}

	public void setOznaka(String oznaka) {
		this.oznaka = oznaka;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	@Override
	public String toString() {
		return "Valuta " + naziv + " sa oznakom " + oznaka;
	}

	public String toFileRepresentation() {
		return oznaka + ", " + naziv;
	}

}
