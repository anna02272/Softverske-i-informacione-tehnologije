package test.model;

public class Racun {
    protected int id;
	protected String sifra;
	protected String vlasnik;
	protected double stanje;
	protected double ras_stanje;
	
	public Racun() {}

	public Racun(int id, String sifra, String vlasnik, double stanje, double ras_stanje) {
		this.id = id;
		this.sifra = sifra;
		this.vlasnik = vlasnik;
		this.stanje = stanje;
		this.ras_stanje = ras_stanje;
	}

	@Override
	public String toString() {
		return "Vlasnik racuna, sifre " + sifra + ", je " + vlasnik + ". Stanje: " + stanje + "; Raspolozivo: " + ras_stanje;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Racun other = (Racun) obj;
		if (id != other.id)
			return false;
		return true;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSifra() {
		return sifra;
	}

	public void setSifra(String sifra) {
		this.sifra = sifra;
	}

	public String getVlasnik() {
		return vlasnik;
	}

	public void setVlasnik(String vlasnik) {
		this.vlasnik = vlasnik;
	}

	public double getStanje() {
		return stanje;
	}

	public void setStanje(double stanje) {
		this.stanje = stanje;
	}

	public double getRas_stanje() {
		return ras_stanje;
	}

	public void setRas_stanje(double ras_stanje) {
		this.ras_stanje = ras_stanje;
	}
}
