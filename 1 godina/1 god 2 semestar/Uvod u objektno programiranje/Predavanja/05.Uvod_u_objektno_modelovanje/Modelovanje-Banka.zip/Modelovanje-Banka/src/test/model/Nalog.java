package test.model;

import java.util.Date;

public class Nalog {
    protected int id;
	protected Racun uplatilac;
	protected Racun primalac;
	protected Date datum_vreme_kr;
	protected double iznos;
	protected Date datum_vreme_real = null;
	
	public Nalog() {}

	public Nalog(int id, Racun uplatilac, Racun primalac, Date datum_vreme_kr, double iznos, Date datum_vreme_real) {
		this.id = id;
		this.primalac = primalac;
		this.uplatilac = uplatilac;
		this.datum_vreme_kr = datum_vreme_kr;
		this.iznos = iznos;
		this.datum_vreme_real = datum_vreme_real;
	}

	@Override
	public String toString() {
		return "Nalog [id=" + id + ", primalac=" + primalac + ", uplatilac=" + uplatilac + ", datum_vreme_kr="
				+ datum_vreme_kr + ", iznos=" + iznos + ", datum_vreme_real=" + datum_vreme_real + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Nalog other = (Nalog) obj;
		if (id != other.id)
			return false;
		return true;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Racun getPrimalac() {
		return primalac;
	}

	public void setPrimalac(Racun primalac) {
		this.primalac = primalac;
	}

	public Racun getUplatilac() {
		return uplatilac;
	}

	public void setUplatilac(Racun uplatilac) {
		this.uplatilac = uplatilac;
	}

	public Date getDatum_vreme_kr() {
		return datum_vreme_kr;
	}

	public void setDatum_vreme_kr(Date datum_vreme_kr) {
		this.datum_vreme_kr = datum_vreme_kr;
	}

	public double getIznos() {
		return iznos;
	}

	public void setIznos(double iznos) {
		this.iznos = iznos;
	}

	public Date getDatum_vreme_real() {
		return datum_vreme_real;
	}

	public void setDatum_vreme_real(Date datum_vreme_real) {
		this.datum_vreme_real = datum_vreme_real;
	}
}
