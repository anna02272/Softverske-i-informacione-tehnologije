DROP SCHEMA IF EXISTS `banka`;
CREATE SCHEMA `banka` DEFAULT CHARACTER SET utf8;
USE banka;


    
CREATE TABLE racun (
	id INT NOT NULL AUTO_INCREMENT,
    sifra VARCHAR(3) NOT NULL,
    vlasnik VARCHAR(4) NOT NULL,
    stanje DOUBLE NOT NULL,
    ras_stanje DOUBLE NOT NULL,
   
    PRIMARY KEY(id)
);
    
CREATE TABLE nalog (
	id INT NOT NULL AUTO_INCREMENT,
    uplatilac_id INT NOT NULL,
    primalac_id INT NOT NULL,
    datum_vreme_kr DATETIME,
    iznos DOUBLE NOT NULL,
    datum_vreme_real DATETIME,
    
	PRIMARY KEY(id),
    FOREIGN KEY(uplatilac_id) REFERENCES racun(id)
		ON DELETE RESTRICT,
	FOREIGN KEY(primalac_id) REFERENCES racun(id)
		ON DELETE RESTRICT
);

INSERT INTO racun (sifra, vlasnik, stanje, ras_stanje) VALUES ('1a', 'a', 200.00, 0.00);
INSERT INTO racun (sifra, vlasnik, stanje, ras_stanje) VALUES ('2b', 'b', 300.00, 0.00);
INSERT INTO racun (sifra, vlasnik, stanje, ras_stanje) VALUES ('3c', 'c', 0.00, 500.00);
INSERT INTO racun (sifra, vlasnik, stanje, ras_stanje) VALUES ('4d', 'd', 150.00, 150.00);
INSERT INTO racun (sifra, vlasnik, stanje, ras_stanje) VALUES ('5e', 'e', 0.00, 0.00);

INSERT INTO nalog (uplatilac_id, primalac_id, datum_vreme_kr, iznos, datum_vreme_real) VALUES (1, 2, '2017-09-01 01:00:00', 100.00, '2017-09-01 23:59:00');
INSERT INTO nalog (uplatilac_id, primalac_id, datum_vreme_kr, iznos, datum_vreme_real) VALUES (1, 3, '2017-09-02 02:00:00', 200.00, NULL);
INSERT INTO nalog (uplatilac_id, primalac_id, datum_vreme_kr, iznos, datum_vreme_real) VALUES (2, 3, '2017-09-03 03:00:00', 300.00, NULL);