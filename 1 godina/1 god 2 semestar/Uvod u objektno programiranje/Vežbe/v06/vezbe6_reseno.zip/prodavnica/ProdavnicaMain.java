package prodavnica;

import java.util.Scanner;

public class ProdavnicaMain {

	public static void main(String[] args) {
		
		Prodavnica prodavnica = new Prodavnica();
		prodavnica.ucitajKorisnike();
		prodavnica.ucitajKomponente();
		prodavnica.ucitajKonfiguracije();
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Dobrodošli. Molimo da se prijavite.");
		System.out.println("Korisničko ime: ");
		String username = scanner.nextLine();
		
		System.out.println("Šifra: ");
		String password = scanner.nextLine();
		
		scanner.close();
		
		if(prodavnica.login(username, password)) {
			System.out.println("TRENUTNO STANJE U PRODAVNICI:");
			
			System.out.println("RACUNARSKE KOMPONENTE: ");
			for (Komponenta komponenta : prodavnica.getKomponente()) {
				System.out.println("\t" + komponenta);
			}
			
			System.out.println("\n\nGOTOVE KONFIGURACIJE: ");
			for (Konfiguracija konfiguracija : prodavnica.getKonfiguracije()) {
				System.out.println("\t" + konfiguracija);
			}
		}else {
			System.out.println("Neispravni login podaci!");
		}
	}
}