package prodavnica;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Prodavnica {

	private ArrayList<Korisnik> korisnici;
	private ArrayList<Komponenta> komponente;
	private ArrayList<Konfiguracija> konfiguracije;

	public Prodavnica() {
		korisnici = new ArrayList<Korisnik>();
		komponente = new ArrayList<Komponenta>();
		konfiguracije = new ArrayList<Konfiguracija>();
	}

	public void ucitajKorisnike() {
		try {
			File korisniciFile = new File("src/prodavnica/fajlovi/korisnici.txt");
			BufferedReader reader = new BufferedReader(new FileReader(korisniciFile));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] lineSplit = line.split("\\|");
				String ime = lineSplit[0];
				String prezime = lineSplit[1];
				String jmbg = lineSplit[2];
				String korisnickoIme = lineSplit[3];
				String sifra = lineSplit[4];

				Korisnik korisnik = new Korisnik(ime, prezime, jmbg, korisnickoIme, sifra);
				this.korisnici.add(korisnik);
			}
		} catch (IOException e) {
			System.out.println("Greska prilikom ucitavanja datoteke: " + e.getMessage());
		}
	}

	public void snimiKorisnike() {
		String sadrzaj = "";
		for (Korisnik korisnik : this.korisnici) {
			sadrzaj += korisnik.getIme() + "|" + korisnik.getPrezime() + "|" + korisnik.getJmbg() + "|" + korisnik.getKorisnickoIme() + 
					"|" + korisnik.getSifra() + "\n";
		}
		try {
			File korisniciFile = new File("src/prodavnica/fajlovi/korisnici.txt");
			BufferedWriter writer = new BufferedWriter(new FileWriter(korisniciFile));
			writer.write(sadrzaj);
			writer.close();
		}catch(IOException e){
			System.out.println("Greska prilikom ucitavanja datoteke: " + e.getMessage());
		}
	}
	
	public void ucitajKomponente() {
		try {
			File korisniciFile = new File("src/prodavnica/fajlovi/komponente.txt");
			BufferedReader reader = new BufferedReader(new FileReader(korisniciFile));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] lineSplit = line.split("\\|");
				String sifra = lineSplit[0];
				String naziv = lineSplit[1];
				String cena = lineSplit[2];
				double cenaDoule = Double.parseDouble(cena);
				String kolicina = lineSplit[3];
				int kolicinaInt = Integer.parseInt(kolicina);
				String opis = lineSplit[4];

				Komponenta komponenta = new Komponenta(sifra, naziv, cenaDoule, kolicinaInt, opis);
				this.komponente.add(komponenta);
			}
		} catch (IOException e) {
			System.out.println("Greska prilikom ucitavanja datoteke: " + e.getMessage());
		}
	}
	
	public Komponenta nadjiKomponentu(String sifra) {
		for (Komponenta komponenta : komponente) {
			if(komponenta.getSifra().equals(sifra)) {
				return komponenta;
			}
		}
		return null;
	}
	
	public void ucitajKonfiguracije() {
		try {
			File korisniciFile = new File("src/prodavnica/fajlovi/konfiguracije.txt");
			BufferedReader reader = new BufferedReader(new FileReader(korisniciFile));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] lineSplit = line.split("\\|");
				String sifra = lineSplit[0];
				String naziv = lineSplit[1];
				String cena = lineSplit[2];
				double cenaDoule = Double.parseDouble(cena);
				String kolicina = lineSplit[3];
				int kolicinaInt = Integer.parseInt(kolicina);
				String opis = lineSplit[4];
				String komponente = lineSplit[5];
				String[] komponenteSplit = komponente.split(";");
				
				ArrayList<Komponenta> komps = new ArrayList<Komponenta>();
				for (String sif : komponenteSplit) {
					Komponenta k = nadjiKomponentu(sif);
					if(k != null) {
						komps.add(k);
					}
				}

				Konfiguracija konfiguracija = new Konfiguracija(sifra, naziv, cenaDoule, kolicinaInt, opis, komps);
				this.konfiguracije.add(konfiguracija);
			}
		} catch (IOException e) {
			System.out.println("Greska prilikom ucitavanja datoteke: " + e.getMessage());
		}
	}
	
	public boolean login(String korisnickoIme, String sifra) {
		for (Korisnik korisnik : korisnici) {
			if(korisnik.getKorisnickoIme().equalsIgnoreCase(korisnickoIme) && korisnik.getSifra().equals(sifra)) {
				return true;
			}
		}
		return false;
	}

	public ArrayList<Korisnik> getKorisnici() {
		return korisnici;
	}

	public void setKorisnici(ArrayList<Korisnik> korisnici) {
		this.korisnici = korisnici;
	}

	public ArrayList<Komponenta> getKomponente() {
		return komponente;
	}

	public void setKomponente(ArrayList<Komponenta> komponente) {
		this.komponente = komponente;
	}

	public ArrayList<Konfiguracija> getKonfiguracije() {
		return konfiguracije;
	}

	public void setKonfiguracije(ArrayList<Konfiguracija> konfiguracije) {
		this.konfiguracije = konfiguracije;
	}
}