package rekurzija;

import java.util.ArrayList;
import java.util.Scanner;

import org.omg.CORBA.portable.ApplicationException;

public class VracanjeKusura {

	private static int[] apoeni = new int[] { 1000, 500, 200, 100, 50, 20, 10, 5, 2, 1 };
	private static ArrayList<Integer> kusurLista = new ArrayList<Integer>();

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Unesite cenu proizvoda: ");
		int cena = scanner.nextInt();
		System.out.println("Unesite koliko je placeno: ");
		int placeno = scanner.nextInt();
		
		if(placeno < cena) {
			System.out.println("Nije placen dovoljan iznos.");
			return;
		}
		
		vratiKusur(placeno - cena, 0);
		System.out.println("Treba da vratite sledece novcanice: ");
		for (int i = 0; i < kusurLista.size(); i++) {
			int koliko = kusurLista.get(i);
			int cega = apoeni[i];
			if (koliko > 0) {
				System.out.println("\t" + koliko + " x " + cega + "din");
			}
		}
	}

	public static void vratiKusur(int kusur, int trenutniApoen) {
		if(kusur == 0) {
			return;
		}else {
			int trenutnaNovcanica = apoeni[trenutniApoen];
			if (trenutnaNovcanica > kusur) {
				kusurLista.add(0);
			}else {
				int koliko = kusur / trenutnaNovcanica;
				kusur = kusur % trenutnaNovcanica;
				kusurLista.add(koliko);
			}
			vratiKusur(kusur, ++trenutniApoen);
		}
	}
}