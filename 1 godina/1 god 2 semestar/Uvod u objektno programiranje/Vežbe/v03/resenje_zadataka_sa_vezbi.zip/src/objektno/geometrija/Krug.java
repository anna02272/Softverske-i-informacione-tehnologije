package objektno.geometrija;

public class Krug {

	public double centarX;
	public double centarY;
	public double poluprecnik;
	
	public Krug(double centarX, double centarY, double poluprecnik) {
		super();
		this.centarX = centarX;
		this.centarY = centarY;
		this.poluprecnik = poluprecnik;
	}
	
	public Krug() {
		this.centarX = 0;
		this.centarY = 0;
		this.poluprecnik = 0;
	}
	
	public Krug(Krug original) {
		this.centarX = original.centarX;
		this.centarY = original.centarY;
		this.poluprecnik = original.poluprecnik;
	}
	
	public double izracunajObim() {
		return 2*this.poluprecnik * Math.PI;
	}
	
	public double izracunajPovrsinu() {
		return Math.pow(this.poluprecnik, 2) * Math.PI;
	}
	
	public boolean tackaPripadaKrugu(Tacka tacka) {
		double d = Math.sqrt(Math.pow((tacka.x - this.centarX), 2) + 
				Math.pow((tacka.y - this.centarY), 2));
		if(d > this.poluprecnik) {
			return false;
		}else {
			return true;
		}
	}
}