package objektno.geometrija;

public class GeometrijaTest {

	public static void main(String[] args) {

		Krug krug1 = new Krug(10, 5.4, 45);
		Krug krug2 = new Krug(0.2, 15, 3);
		Tacka tacka1 = new Tacka(2, 4);
		Tacka tacka2 = new Tacka(6, 10);
		
		System.out.println("Krug 1: centar = (" + krug1.centarX + ", " + krug1.centarY + 
				") ,poluprecnik = " + krug1.poluprecnik);
		System.out.println("Krug 2: centar = (" + krug2.centarX + ", " + krug2.centarY + 
				") ,poluprecnik = " + krug2.poluprecnik);
		System.out.println("Tacka 1: " + tacka1.x + ", " + tacka1.y);
		System.out.println("Tacka 2: " + tacka2.x + ", " + tacka2.y);
		System.out.println("Tacka 1 pripada krugu 1: " + krug1.tackaPripadaKrugu(tacka1));
		System.out.println("Tacka 2 pripada krugu 1: " + krug1.tackaPripadaKrugu(tacka2));
		System.out.println("Tacka 1 pripada krugu 2: " + krug2.tackaPripadaKrugu(tacka1));
		System.out.println("Tacka 2 pripada krugu 2: " + krug2.tackaPripadaKrugu(tacka2));
	}
}