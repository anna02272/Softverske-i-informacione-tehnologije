package objektno.geometrija;

public class Tacka {

	public double x;
	public double y;
	
	public Tacka(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	public Tacka() {
		this.x = 0;
		this.y = 0;
	}
	
	public Tacka(Tacka original) {
		this.x = original.x;
		this.y = original.y;
	}
}