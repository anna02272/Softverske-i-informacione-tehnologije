package zadatak01;

public class Pravougaonik {

	double a, b, x, y;
	
	public Pravougaonik() {
		this.a = 0;
		this.b = 0;
		this.x = 0;
		this.y = 0;
	}
	
	public Pravougaonik(double a, double b, double x, double y) {
		this.a = a;
		this.b = b;
		this.x = x;
		this.y = y;
	}
	
	public Pravougaonik(Pravougaonik original) {
		this.a = original.a;
		this.b = original.b;
		this.x = original.x;
		this.y = original.y;
	}
	
	double obim() {
		return 2*a + 2*b;
	}
	
	double povrsina() {
		return a*b;
	}
	
}