package zadatak02;

public class Predmet {

	String sifraPredmeta;
	String nazivPredmeta;
	int semestar;
	String profesor;
	
	public Predmet() {
		this.sifraPredmeta = "";
		this.nazivPredmeta = "";
		this.semestar = 1;
		this.profesor = "";
	}

	public Predmet(String sifraPredmeta, String nazivPredmeta, int semestar, String profesor) {
		super();
		this.sifraPredmeta = sifraPredmeta;
		this.nazivPredmeta = nazivPredmeta;
		this.semestar = semestar;
		this.profesor = profesor;
	}
	
	public Predmet(Predmet original) {
		this.sifraPredmeta = original.sifraPredmeta;
		this.nazivPredmeta = original.nazivPredmeta;
		this.semestar = original.semestar;
		this.profesor = original.profesor;
	}
}