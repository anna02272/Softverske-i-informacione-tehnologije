package zadatak02;

public class Ocena {

	Student student;
	Predmet predmet;
	int ocena;
	
	public Ocena() {
		this.student = new Student();
		this.predmet = new Predmet();
		this.ocena = 5;
	}

	public Ocena(Student student, Predmet predmet, int ocena) {
		this.student = student;
		this.predmet = predmet;
		this.ocena = ocena;
	}
	
	public Ocena(Ocena original) {
		this.student = original.student;
		this.predmet = original.predmet;
		this.ocena = original.ocena;
	}
}