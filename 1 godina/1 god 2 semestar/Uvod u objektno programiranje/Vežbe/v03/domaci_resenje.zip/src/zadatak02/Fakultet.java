package zadatak02;

public class Fakultet {

	String naziv;
	String adresa;
	Student[] studenti;
	Predmet[] predmeti;
	Ocena[] ocene;
	
	public Fakultet() {
		this.naziv = "";
		this.adresa = "";
		this.studenti = new Student[500];
		this.predmeti = new Predmet[150];
		this.ocene = new Ocena[1000];
	}

	public Fakultet(String naziv, String adresa, Student[] studenti, Predmet[] predmeti, Ocena[] ocene) {
		this.naziv = naziv;
		this.adresa = adresa;
		this.studenti = studenti;
		this.predmeti = predmeti;
		this.ocene = ocene;
	}

	public Fakultet(Fakultet original) {
		this.naziv = original.naziv;
		this.adresa = original.adresa;
		this.studenti = original.studenti;
		this.predmeti = original.predmeti;
		this.ocene = original.ocene;
	}
}