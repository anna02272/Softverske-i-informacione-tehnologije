package zadatak02;

public class FakultetMain {

	public static void main(String[] args) {
		Student student1 = new Student("RS 1/2016", "Marko Markovic", 2016, new int[] {10, 7, 8, 10});
		Student student2 = new Student("RS 2/2016", "Vesna Simic", 2016, new int[] {9, 10, 6, 10});
		Student student3 = new Student("RS 3/2016", "Jelena Markovic", 2016, new int[] {10, 10, 10, 10});
		Student student4 = new Student("RS 4/2016", "Marko Simic", 2016, new int[] {6, 7, 8, 8});
		
		Predmet predmet1 = new Predmet("P1", "Telekomunikacije", 1, "Nikola Tesla");
		Predmet predmet2 = new Predmet("P2", "Uvod u psihoanalizu", 1, "Slavoj Zizek");
		Predmet predmet3 = new Predmet("P3", "Osnove kosarke", 1, "Magic Johnson");
		Predmet predmet4 = new Predmet("P4", "Primenjena matematika", 1, "Stevan Mokranjac");
		
		Ocena ocena1 = new Ocena(student1, predmet3, 10);
		Ocena ocena2 = new Ocena(student4, predmet4, 7);
		Ocena ocena3 = new Ocena(student2, predmet3, 8);
		Ocena ocena4 = new Ocena(student3, predmet1, 9);
		Ocena ocena5 = new Ocena(student3, predmet4, 6);
		Ocena ocena6 = new Ocena(student1, predmet2, 10);
		
		Fakultet fakultet = new Fakultet(
				"Fakultet Tehnickih Nauka", 
				"Trg Dositeja Obradovica 6, Novi Sad",
				new Student[] {student1, student2, student3, student4}, 
				new Predmet[] {predmet1, predmet2, predmet3, predmet4},
				new Ocena[] {ocena1, ocena2, ocena3, ocena4, ocena5, ocena6});
		
		System.out.println("--------------------------------------------------------");
		System.out.println(fakultet.naziv);
		System.out.println(fakultet.adresa);
		System.out.println("--------------------------------------------------------");
		System.out.println("Studenti na fakultetu: ");
		for (int i = 0; i < fakultet.studenti.length; i++) {
			System.out.println("\t" + fakultet.studenti[i].indeks + " " + fakultet.studenti[i].imeIPrezime);
		}
		System.out.println();
		System.out.println("Predmeti na fakultetu: ");
		for (int i = 0; i < fakultet.predmeti.length; i++) {
			System.out.println("\t" + fakultet.predmeti[i].sifraPredmeta + " " + fakultet.predmeti[i].nazivPredmeta + "(" + fakultet.predmeti[i].profesor + ")");
		}
		System.out.println();
		for (int i = 0; i < fakultet.ocene.length; i++) {
			System.out.println("Student " + fakultet.ocene[i].student.imeIPrezime + " iz predmeta " + fakultet.ocene[i].predmet.nazivPredmeta + " ima ocenu: " + fakultet.ocene[i].ocena);
		}
	}
}