package zadatak02;

public class Student {

	String indeks;
	String imeIPrezime;
	int godinaUpisa;
	int[] ocene;
	
	public Student() {
		this.indeks = "";
		this.imeIPrezime = "";
		this.godinaUpisa = 0;
		this.ocene = new int[10];
	}
	
	public Student(String indeks, String imeIPrezime, int godinaUpisa, int[] ocene) {
		this.indeks = indeks;
		this.imeIPrezime = imeIPrezime;
		this.godinaUpisa = godinaUpisa;
		this.ocene = ocene;
	}
	
	public Student(Student original) {
		this.indeks = original.indeks;
		this.imeIPrezime = original.imeIPrezime;
		this.godinaUpisa = original.godinaUpisa;
		this.ocene = original.ocene;
	}
	
}