package proizvodi;

public class Komponenta extends Proizvod {
	private Kategorija kategorija;
	
	public Komponenta() {
		super();
		this.kategorija = new Kategorija();
	}

	public Komponenta(String sifra, String naziv, double cena, int raspolozivaKolicina, String opis, Kategorija kategorija) {
		super(sifra, naziv, cena, raspolozivaKolicina, opis);
		this.kategorija = kategorija;
	}

	public Kategorija getKategorija() {
		return kategorija;
	}

	public void setKategorija(Kategorija kategorija) {
		this.kategorija = kategorija;
	}

	@Override
	public String toString() {
		return "Komponenta [kategorija=" + kategorija + ", sifra=" + sifra + ", naziv=" + naziv + ", cena=" + cena
				+ ", raspolozivaKolicina=" + raspolozivaKolicina + ", opis=" + opis + "]";
	}
}
