package racuni;

import proizvodi.Komponenta;
import proizvodi.Proizvod;

public class StavkaRacuna {
	private int redniBroj;
	private Proizvod artikal;
	private int kolicina;
	
	public StavkaRacuna() {
		this.redniBroj = 0;
		// Posto ne mozemo da inicijalizujemo klasu Proizvod,
		// ovde cemo staviti instancu bilo koje klase koja je nasledjuje (a da nije apstraktna).
		this.artikal = new Komponenta();
		this.kolicina = 0;
	}

	public StavkaRacuna(int redniBroj, Proizvod artikal, int kolicina) {
		super();
		this.redniBroj = redniBroj;
		this.artikal = artikal;
		this.kolicina = kolicina;
	}

	public int getRedniBroj() {
		return redniBroj;
	}

	public void setRedniBroj(int redniBroj) {
		this.redniBroj = redniBroj;
	}

	public Proizvod getArtikal() {
		return artikal;
	}

	public void setArtikal(Proizvod artikal) {
		this.artikal = artikal;
	}

	public int getKolicina() {
		return kolicina;
	}

	public void setKolicina(int kolicina) {
		this.kolicina = kolicina;
	}

	@Override
	public String toString() {
		return "StavkaRacuna [redniBroj=" + redniBroj + ", artikal=" + artikal + ", kolicina=" + kolicina + "]";
	}
}
