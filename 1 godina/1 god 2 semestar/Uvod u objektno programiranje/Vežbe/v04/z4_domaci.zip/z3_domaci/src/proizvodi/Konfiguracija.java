package proizvodi;

import java.util.ArrayList;

public class Konfiguracija extends Proizvod {
	// Kada budemo nau�ili liste, ovde je bolje koristiti listu umesto niza
	private Komponenta[] komponente;
	
	public Konfiguracija() {
		super();
		this.komponente = new Komponenta[20];
	}

	public Konfiguracija(String sifra, String naziv, double cena, int raspolozivaKolicina, String opis, Komponenta[] komponente) {
		super(sifra, naziv, cena, raspolozivaKolicina, opis);
		this.komponente = komponente;
	}

	public Komponenta[] getKomponente() {
		return komponente;
	}

	public void setKomponente(Komponenta[] komponente) {
		this.komponente = komponente;
	}

	@Override
	public String toString() {
		return "Konfiguracija [komponente=" + komponente + ", sifra=" + sifra + ", naziv=" + naziv + ", cena=" + cena
				+ ", raspolozivaKolicina=" + raspolozivaKolicina + ", opis=" + opis + "]";
	}
}
