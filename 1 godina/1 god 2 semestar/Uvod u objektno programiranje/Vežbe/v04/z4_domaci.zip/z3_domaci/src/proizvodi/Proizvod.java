package proizvodi;

public abstract class Proizvod {
	protected String sifra;
	protected String naziv;
	protected double cena;
	protected int raspolozivaKolicina;
	protected String opis;

	public Proizvod() {
		this.sifra = "";
		this.naziv = "";
		this.cena = 0;
		this.raspolozivaKolicina = 0;
		this.opis = "";
	}

	public Proizvod(String sifra, String naziv, double cena, int raspolozivaKolicina, String opis) {
		super();
		this.sifra = sifra;
		this.naziv = naziv;
		this.cena = cena;
		this.raspolozivaKolicina = raspolozivaKolicina;
		this.opis = opis;
	}

	public String getSifra() {
		return sifra;
	}

	public void setSifra(String sifra) {
		this.sifra = sifra;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public double getCena() {
		return cena;
	}

	public void setCena(double cena) {
		this.cena = cena;
	}

	public int getRaspolozivaKolicina() {
		return raspolozivaKolicina;
	}

	public void setRaspolozivaKolicina(int raspolozivaKolicina) {
		this.raspolozivaKolicina = raspolozivaKolicina;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	@Override
	public String toString() {
		return "Proizvod [sifra=" + sifra + ", naziv=" + naziv + ", cena=" + cena + ", raspolozivaKolicina="
				+ raspolozivaKolicina + ", opis=" + opis + "]";
	}
}
