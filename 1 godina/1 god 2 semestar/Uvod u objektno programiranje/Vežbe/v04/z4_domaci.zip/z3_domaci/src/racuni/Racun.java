package racuni;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import korisnici.Korisnik;

public class Racun {
	private String sifra;
	private Korisnik prodavac;
	private Date vremeProdaje;
	// Isto kao i sa konfiguracijom, ovde je bolje koristiti listu
	private StavkaRacuna[] stavke;
	
	public Racun() {
		this.sifra = "";
		this.prodavac = new Korisnik();
		this.vremeProdaje = new Date();
		this.stavke = new StavkaRacuna[50];
	}

	public Racun(String sifra, Korisnik prodavac, Date vremeProdaje, StavkaRacuna[] stavke) {
		super();
		this.sifra = sifra;
		this.prodavac = prodavac;
		this.vremeProdaje = vremeProdaje;
		this.stavke = stavke;
	}

	public String getSifra() {
		return sifra;
	}

	public void setSifra(String sifra) {
		this.sifra = sifra;
	}

	public Korisnik getProdavac() {
		return prodavac;
	}

	public void setProdavac(Korisnik prodavac) {
		this.prodavac = prodavac;
	}

	public Date getVremeProdaje() {
		return vremeProdaje;
	}

	public void setVremeProdaje(Date vremeProdaje) {
		this.vremeProdaje = vremeProdaje;
	}

	public StavkaRacuna[] getStavke() {
		return stavke;
	}

	public void setStavke(StavkaRacuna[] stavke) {
		this.stavke = stavke;
	}

	// Umesto da ukupnu cenu pamtimo u atributu, bolje je napraviti metodu koja ce izracunati cenu
	// tako sto ce sabrati cene pomnozene sa kupljenim kolicinama svih proizvoda u stavkama
	public double izracunajCenu() {
		double cena = 0;
		for (StavkaRacuna stavkaRacuna : this.stavke) {
			cena += stavkaRacuna.getArtikal().getCena() * stavkaRacuna.getKolicina();
		}
		return cena;
	}
	
	// Malo cemo modifikovati ovu metodu kako bi dobili lepsi ispis podataka o racunu:
	@Override
	public String toString() {
		// Formatiranje datuma (vise o tome na nekim od sledecih vezbi)
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm");
		// Opsti podaci o racunu:
		String racun = 
				"RACUN:\t\t" + this.sifra + "\n" +
				"Datum:\t\t" + formatter.format(this.vremeProdaje) + "h\n" + 
				"Prodavac:\t" + this.prodavac.getKorisnickoIme() + "\n" + 
				"---------------------------------------------------\n";
		// Za svaku stavku stampamo naziv, kupljenu kolicinu i cenu
		for (StavkaRacuna stavkaRacuna : this.stavke) {
			racun += stavkaRacuna.getRedniBroj() + "\t" + stavkaRacuna.getArtikal().getNaziv() + "\t\t" + stavkaRacuna.getKolicina() + " x " + stavkaRacuna.getArtikal().getCena() + "\n";
		}
		// Na kraju ispisemo ukupnu cenu racuna
		racun += "---------------------------------------------------\n" + 
				"TOTAL: \t" + this.izracunajCenu();
		return racun;
	}
}
