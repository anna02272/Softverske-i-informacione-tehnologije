package main;

import java.util.Date;

import korisnici.Korisnik;
import korisnici.Uloga;
import proizvodi.Kategorija;
import proizvodi.Komponenta;
import racuni.Racun;
import racuni.StavkaRacuna;

public class ProdavnicaMain {

	public static void main(String[] args) {
		Korisnik prodavac = new Korisnik("Mile", "Milic", "milem", "12345", Uloga.ADMINISTRATOR);

		Kategorija katKomponente = new Kategorija("K001", "Racunarske komponente", "Komponente racunara", null);
		Kategorija katPeriferije = new Kategorija("K002", "Periferije", "Periferni uredjaji", null);
		Kategorija katMonitori = new Kategorija("K003", "Monitori", "Monitori svih vrsta", katPeriferije);
		
		Komponenta grafickaKartica = new Komponenta("G001", "GeForce GTX 1050Ti", 25000, 15, "GeForce graficka kartica", katKomponente);
		Komponenta monitor = new Komponenta("M001", "Samsung SyncMaster 24'", 54000, 5, "Samsung monitor 24 inca", katMonitori);
		Komponenta tastatura = new Komponenta("P001", "Genius tastatura", 2100, 30, "Genius USB tastatura", katPeriferije);
		
		StavkaRacuna stavkaA = new StavkaRacuna(1, grafickaKartica, 1);
		StavkaRacuna stavkaB = new StavkaRacuna(2, monitor, 2);
		StavkaRacuna stavkaC = new StavkaRacuna(3, tastatura, 1);
		
		StavkaRacuna[] stavke = new StavkaRacuna[] {stavkaA, stavkaB, stavkaC};
		Racun racun = new Racun("R001", prodavac, new Date(), stavke);
		
		System.out.println(racun);
	}
}
