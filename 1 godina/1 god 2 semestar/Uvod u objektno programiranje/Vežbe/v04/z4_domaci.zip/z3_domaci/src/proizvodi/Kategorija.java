package proizvodi;

public class Kategorija {
	private String sifra;
	private String naziv;
	private String opis;
	// Klase mogu da imaju atribute koji su objekti iste te klase
	// ("klasa ima vezu sama na sebe")
	private Kategorija nadkategorija;
	
	public Kategorija() {
		this.sifra = "";
		this.naziv = "";
		this.opis = "";
		this.nadkategorija = new Kategorija();
	}
	
	public Kategorija(String sifra, String naziv, String opis, Kategorija nadkategorija) {
		super();
		this.sifra = sifra;
		this.naziv = naziv;
		this.opis = opis;
		this.nadkategorija = nadkategorija;
	}

	public String getSifra() {
		return sifra;
	}

	public void setSifra(String sifra) {
		this.sifra = sifra;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public Kategorija getNadkategorija() {
		return nadkategorija;
	}

	public void setNadkategorija(Kategorija nadkategorija) {
		this.nadkategorija = nadkategorija;
	}

	@Override
	public String toString() {
		return "Kategorija [sifra=" + sifra + ", naziv=" + naziv + ", opis=" + opis + ", nadkategorija=" + nadkategorija
				+ "]";
	}
}
