package korisnici;

/**
 *	Primer Java enumeracije (https://docs.oracle.com/javase/tutorial/java/javaOO/enum.html)
 *
 *	Enumeracije su Java tipovi koje koristimo kada imamo ograni�en skup vrednosti.
 *	Radi�emo ih detaljno na nekim od slede�ih ve�bi, ovde je samo jedan primer kori��enja
 *	s obzirom da atribut uloga u klasi Korisnik mo�e da ima sa dve vrednosti.
 *	Ovo smo mogli da postignemo i sa String tipom ali onda moramo ru�no da vodimo ra�una
 *	da vrednost bude ili Korisnik ili Administrator.
 */
public enum Uloga {
	KORISNIK,
	ADMINISTRATOR
}
