package osnovneKlase;

public abstract class Zaposleni extends Osoba {

	public Zaposleni() {
		super();
	}
	
	public Zaposleni(String ime, String prezime, String adresa, String brojTelefona) {
		super(ime, prezime, adresa, brojTelefona);
	}
	
	public Zaposleni(Zaposleni original) {
		super(original);
	}
	
	public abstract double izracunajPlatu();
	
}