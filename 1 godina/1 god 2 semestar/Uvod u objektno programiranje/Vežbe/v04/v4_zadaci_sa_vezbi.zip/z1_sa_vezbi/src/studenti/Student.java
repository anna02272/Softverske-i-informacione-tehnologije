package studenti;

import java.util.Arrays;

import osnovneKlase.Osoba;

public class Student extends Osoba {

	private String brojIndeksa;
	private int[] ocene;
	
	public Student() {
		super();
		this.brojIndeksa = "";
		this.ocene = new int[30];
	}

	public Student(String ime, String prezime, String adresa, String brojTelefona, String brojIndeksa, int[] ocene) {
		super(ime, prezime, adresa, brojTelefona);
		this.brojIndeksa = brojIndeksa;
		this.ocene = ocene;
	}
	
	public Student(Student original) {
		super(original);
		this.brojIndeksa = original.brojIndeksa;
		this.ocene = original.ocene;
	}

	public String getBrojIndeksa() {
		return brojIndeksa;
	}

	public void setBrojIndeksa(String brojIndeksa) {
		this.brojIndeksa = brojIndeksa;
	}

	public int[] getOcene() {
		return ocene;
	}

	public void setOcene(int[] ocene) {
		this.ocene = ocene;
	}

	@Override
	public String toString() {
		return  super.toString() + "\nStudent [brojIndeksa=" + brojIndeksa + ", ocene=" + Arrays.toString(ocene) + "]";
	}
	
	
}