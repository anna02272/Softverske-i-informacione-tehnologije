package zaposleni;

import osnovneKlase.Zaposleni;

public class Asistent extends Zaposleni {

	private int brojVezbi;
	private Profesor mentor;
	
	public Asistent() {
		super();
		this.brojVezbi = 0;
		this.mentor = new Profesor();
	}
	
	public Asistent(String ime, String prezime, String adresa, String brojTelefona, int brojVezbi, Profesor mentor) {
		super(ime, prezime, adresa, brojTelefona);
		this.brojVezbi = brojVezbi;
		this.mentor = mentor;
	}

	public Asistent(Asistent original) {
		super(original);
		this.brojVezbi = original.brojVezbi;
		this.mentor = original.mentor;
	}

	@Override
	public double izracunajPlatu() {
		return this.brojVezbi * 100;
	}

	@Override
	public String toString() {
		return super.toString() + "\nAsistent [brojVezbi=" + brojVezbi + ", mentor=" + mentor.getIme() + " " + mentor.getPrezime() + ", plata=" + this.izracunajPlatu() + "]";
	}
}