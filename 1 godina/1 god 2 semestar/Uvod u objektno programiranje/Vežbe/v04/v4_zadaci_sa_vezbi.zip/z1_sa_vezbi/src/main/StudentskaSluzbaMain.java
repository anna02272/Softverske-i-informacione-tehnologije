package main;

import osnovneKlase.Zaposleni;
import studenti.Student;
import zaposleni.Asistent;
import zaposleni.Profesor;

public class StudentskaSluzbaMain {

	public static void main(String[] args) {
		Student studentA = new Student("Petar", "Petrovic", "Novi Sad 1A", "111-222", "SF01-2016", new int[] {10, 7, 9});
		Student studentB = new Student("Marija", "Maric", "Novi Sad 1B", "222-333", "SF02-2016", new int[] {9, 8, 9});
		Student studentC = new Student("Mirko", "Mirkovic", "Novi Sad 1C", "333-444", "SF03-2016", new int[] {6, 8, 7});
		Student studentD = new Student("Jovana", "Jovanovic", "Novi Sad 1D", "444-555", "SF04-2016", new int[] {10, 10, 10});
		
		Profesor profesorA = new Profesor("Nikola", "Nikolic", "Novi Sad 2A", "555-666", 10);
		
		Asistent asistentA = new Asistent("Zlata", "Zlatic", "Novi Sad 3A", "666-777", 15, profesorA);
		Asistent asistentB = new Asistent("Mile", "Milic", "Novi Sad 3B", "777-888", 12, profesorA);
		
		System.out.println("STUDENTI: ");
		System.out.println(studentA);
		System.out.println(studentB);
		System.out.println(studentC);
		System.out.println(studentD);
		System.out.println("PROFESORI:");
		System.out.println(profesorA);
		System.out.println("ASISTENTI:");
		System.out.println(asistentA);
		System.out.println(asistentB);
		
		Zaposleni[] radniciNaFakultetu = new Zaposleni[] {profesorA, asistentA, asistentB};
		int brojProfesora = 0, brojAsistenata = 0;
		for (int i = 0; i < radniciNaFakultetu.length; i++) {
			Zaposleni z = radniciNaFakultetu[i];
			if(z instanceof Profesor) {
				brojProfesora++;
			}
			if(z instanceof Asistent) {
				brojAsistenata++;
			}
		}
		System.out.println("Ukupo radnika za fakultetu: " + radniciNaFakultetu.length);
		System.out.println("Broj profesora: " + brojProfesora);
		System.out.println("Broj asistenata: " + brojAsistenata);
	}
}