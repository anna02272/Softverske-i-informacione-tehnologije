package zaposleni;

import osnovneKlase.Zaposleni;;

public class Profesor extends Zaposleni {

	private int brojPredavanja;
	
	public Profesor() {
		super();
		this.brojPredavanja = 0;
	}
	
	public Profesor(String ime, String prezime, String adresa, String brojTelefona, int brojPredavanja) {
		super(ime, prezime, adresa, brojTelefona);
		this.brojPredavanja = brojPredavanja;
	}

	public Profesor(Profesor original) {
		super(original);
		this.brojPredavanja = original.brojPredavanja;
	}

	public int getBrojPredavanja() {
		return brojPredavanja;
	}

	public void setBrojPredavanja(int brojPredavanja) {
		this.brojPredavanja = brojPredavanja;
	}

	@Override
	public double izracunajPlatu() {
		return this.brojPredavanja * 150;
	}

	@Override
	public String toString() {
		return super.toString() +  "\nProfesor [brojPredavanja=" + brojPredavanja + ", plata=" + this.izracunajPlatu() + "]";
	}
	
}
