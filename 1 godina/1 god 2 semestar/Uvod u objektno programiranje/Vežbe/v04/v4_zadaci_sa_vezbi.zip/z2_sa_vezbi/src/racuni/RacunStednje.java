package racuni;

import klijenti.Osoba;

public class RacunStednje extends Racun {

	private boolean pokrenutaStednja;
	private double godisnjiKoeficijentStednje;
	
	public RacunStednje() {
		super();
		this.pokrenutaStednja = false;
		this.godisnjiKoeficijentStednje = 0;
	}

	
	public RacunStednje(Osoba vlasnikRacuna, double stanje, boolean pokrenutaStednja, double godisnjiKoeficijentStednje) {
		super(vlasnikRacuna, stanje);
		this.pokrenutaStednja = pokrenutaStednja;
		this.godisnjiKoeficijentStednje = godisnjiKoeficijentStednje;
	}

	public RacunStednje(RacunStednje original) {
		super(original);
		this.pokrenutaStednja = original.pokrenutaStednja;
		this.godisnjiKoeficijentStednje = original.godisnjiKoeficijentStednje;
	}

	public double getGodisnjiKoeficijentStednje() {
		return godisnjiKoeficijentStednje;
	}

	public void setGodisnjiKoeficijentStednje(double godisnjiKoeficijentStednje) {
		this.godisnjiKoeficijentStednje = godisnjiKoeficijentStednje;
	}

	public boolean isPokrenutaStednja() {
		return pokrenutaStednja;
	}

	@Override
	public String toString() {
		return "RacunStednje [pokrenutaStednja=" + pokrenutaStednja + ", vlasnikRacuna=" + vlasnikRacuna + ", stanje="
				+ stanje + "]";
	}

	public void pokreniStednju() {
		this.pokrenutaStednja = true;
	}
	
	public void obustaviStednju(int meseci) {
		int brojGodina = meseci / 12;
		int ostatakMeseci = meseci % 12;
		
		this.stanje += this.stanje * (this.godisnjiKoeficijentStednje*0.01*brojGodina)+this.stanje*(this.godisnjiKoeficijentStednje*0.01*ostatakMeseci/12);
		this.pokrenutaStednja = false;
	}
	
	@Override
	public boolean isplata(double suma) {
		if((this.stanje - suma) > 0 && !this.isPokrenutaStednja()) {
			this.stanje -= suma;
			return true;
		}else {
			return false;
		}
	}

	@Override
	public void uplata(double suma) {
		this.stanje += suma;
	}
}
