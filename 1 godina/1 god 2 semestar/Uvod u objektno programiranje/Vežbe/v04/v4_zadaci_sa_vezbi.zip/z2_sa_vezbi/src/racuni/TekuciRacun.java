package racuni;

import klijenti.Osoba;

public class TekuciRacun extends Racun {

	private double mesecnaNaknada;

	public TekuciRacun() {
		super();
		this.mesecnaNaknada = 0;
	}
	
	public TekuciRacun(Osoba vlasnikRacuna, double stanje, double mesecnaNaknada) {
		super(vlasnikRacuna, stanje);
		this.mesecnaNaknada = mesecnaNaknada;
	}

	public TekuciRacun(TekuciRacun original) {
		super(original);
		this.mesecnaNaknada = original.mesecnaNaknada;
	}

	public double obracunajMesecnuNaknadu() {
		if((this.stanje - this.mesecnaNaknada) > 0) {
			return this.stanje - this.mesecnaNaknada;
		}else {
			System.out.println("Mesecna naknada ne moze biti naplacena trenutno.");
			return this.stanje;
		}
	}
	
	@Override
	public boolean isplata(double suma) {
		if((this.stanje - suma) > 0) {
			this.stanje -= suma;
			return true;
		}else {
			return false;
		}
	}

	@Override
	public void uplata(double suma) {
		this.stanje += suma*0.99;
	}

	@Override
	public String toString() {
		return "TekuciRacun [mesecnaNaknada=" + mesecnaNaknada + ", vlasnikRacuna=" + vlasnikRacuna + ", stanje="
				+ stanje + "]";
	}

	
	
}
