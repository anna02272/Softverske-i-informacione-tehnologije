package racuni;

import klijenti.Osoba;

public abstract class Racun {

	protected Osoba vlasnikRacuna;
	protected double stanje;
	
	public Racun() {
		this.vlasnikRacuna = new Osoba();
		this.stanje = 0;
	}
	
	public Racun(Osoba vlasnikRacuna, double stanje) {
		super();
		this.vlasnikRacuna = vlasnikRacuna;
		this.stanje = stanje;
	}

	public Racun(Racun original) {
		this.vlasnikRacuna = original.vlasnikRacuna;
		this.stanje = original.stanje;
	}

	public Osoba getVlasnikRacuna() {
		return vlasnikRacuna;
	}
	public void setVlasnikRacuna(Osoba vlasnikRacuna) {
		this.vlasnikRacuna = vlasnikRacuna;
	}
	public double getStanje() {
		return stanje;
	}
	// NAPOMENA: Za stanje nam ne treba set metoda, jer se stanje menja metodama uplata i isplata
	
	public abstract boolean isplata(double suma);
	public abstract void uplata(double suma);
	
}