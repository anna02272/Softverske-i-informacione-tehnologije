package main;

import klijenti.Osoba;
import racuni.RacunStednje;
import racuni.TekuciRacun;

public class RacuniMain {

	public static void main(String[] args) {
		
		Osoba klijentA = new  Osoba("111111111", "Milos", "Milosevic");
		
		TekuciRacun tekuci = new TekuciRacun(klijentA, 400, 200);
		RacunStednje stednja = new RacunStednje(klijentA, 7000, true, 0.02);
		
		System.out.println("KLIJENT: " + klijentA);
		System.out.println("INICIJALNO STANJE TEKUCEG RACUNA: " + tekuci.getStanje());
		System.out.println("INICIJALNO STANJE RACUNA STEDNJE: " + stednja.getStanje());
		
		tekuci.isplata(tekuci.obracunajMesecnuNaknadu());
		System.out.println("\nNAPLACENA MESECNA NAKNADA. STANJE TEKUCEG RACUNA: " + tekuci.getStanje());
		System.out.println("KLIJENT PODIZE 1000din SA TEKUCEG RACUNA...");
		if(!tekuci.isplata(1000)) {
			System.out.println("TRAZENA SUMA NIJE RASPOLOZIVA.");
		}else {
			System.out.println("ISPLATA USPESNO OBAVLJENA. STANJE TEKUCEG RACUNA: " + tekuci.getStanje());
		}
		System.out.println("KLIJENT PODIZE 1000din SA RACUNA STEDNJE...");
		if(!stednja.isplata(1000)) {
			System.out.println("TRAZENA SUMA NIJE RASPOLOZIVA.");
		}else {
			System.out.println("ISPLATA USPESNO OBAVLJENA. STANJE STEDNOG RACUNA: " + stednja.getStanje());
		}
		System.out.println("KLIJENT ZAUSTAVLJA STEDNJU NAKON 15 MESECI I PODIZE 1000din SA STEDNOG RACUNA...");
		stednja.obustaviStednju(15);
		System.out.println("STANJE STEDNOG RACUNA NAKON OBUSTAVLJANJA: " + stednja.getStanje());
		if(!stednja.isplata(1000)) {
			System.out.println("TRAZENA SUMA NIJE RASPOLOZIVA.");
		}else {
			System.out.println("ISPLATA USPESNO OBAVLJENA. STANJE STEDNOG RACUNA: " + stednja.getStanje());
		}
	}
}