def power(num, topwr):
    if topwr == 0:
        return 1
    else:
        return num * power(num, topwr - 1)


print(power(3, 9))
print(power(2, 8))
