# funkcija se moze proslediti kao parametar

def greeter():
    print ("Hello")

def ciao():
    print ("Ciao")

def repeater(func, times):
    for i in range(times):
        func()

repeater(greeter, 3)

repeater(ciao, 6)

