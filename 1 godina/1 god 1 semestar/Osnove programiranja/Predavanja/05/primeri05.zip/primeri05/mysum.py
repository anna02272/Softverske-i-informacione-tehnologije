#promenljivi parametri, racuna se suma
def my_sum(*args):
	result = 0
	for x in args:
		print("parametar je ", x)
		result = result + x
	return result



# print("Tri broja")
# print(my_sum(1, 89, 100))
# print()
# print("Nema brojeva")
# print(my_sum())
# print()
# print("Jedna broj")
# print(my_sum(1))
# print()
# print("Pet brojeva")
# print(my_sum(100, 99, 10, 0, 1))



def print_greeting(greeting, *names):
	for name in names:
		print(greeting + " " + name)



print_greeting("Cao", "Pera", "Jelena", "Ivana", "Marko")