def concatenate(**kwargs):
	result = ""
	for arg in kwargs:
		result += arg
		result += " "

	print(result)
	result=""
	for arg in kwargs.values():
		result += arg
		result += " "
	
	print(result)

	print("Indeks je", kwargs["indeks"])



concatenate(ime="Jelena", prezime = "Peric", indeks="SF 12/2021", fakultet = "FTN")