#suma liste

s = [3, 8, -9, 87, -87, 0, 24, 42]

n = 8

sum = 0

for i in range(n):
	sum = sum + s[i]

print("Suma je", sum)

sum = 0
for i in range(len(s)):
	sum = sum + s[i]

print("Suma, opcije dva,", sum)


sum = 0
for i in s:
	sum = sum + i

print("Suma, opcija tri,", sum)




