import math

def getNumbers():
	nums = [] # počnemo sa praznom listom
	
	# sentinel petlja za unos brojeva
	xStr = input("Unesi broj (<Enter> za kraj) >> ")
	while xStr != "":
		x = eval(xStr)
		nums.append(x) # dodaj vrednost na kraj liste
		xStr = input("Unesi broj (<Enter> za kraj) >> ")
	
	return nums


def mean(nums):
	sum = 0.0
	for num in nums:
		sum = sum + num
	
	return sum / len(nums)


def stdDev(nums, avg):
	sumDevSq = 0.0 # akumulator
	for num in nums:
		dev = avg - num
		sumDevSq = sumDevSq + dev * dev
	
	return math.sqrt(sumDevSq/(len(nums)-1))


def median(nums):
	nums.sort()
	
	size = len(nums)

	midPos = size // 2
	if size % 2 == 0:
		median = (nums[midPos] + nums[midPos-1]) / 2
	else:
		median = nums[midPos]
	
	return median


data = getNumbers()

print(data)

avg = mean(data)
print("Srednja vrednost je ", avg)

dev = stdDev(data, avg)
print("Standardna devijacija je ", dev)

median = median(data)
print("Median vrednost je", median)