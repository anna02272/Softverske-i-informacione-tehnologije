#prazna lista
nums = []

#unosimo broj po broj
x = eval(input('Unesite broj (negativan broj za kraj): '))
while x >= 0:
	nums.append(x)
	x = eval(input('Unesite broj (negativan broj za kraj): '))

#prikaz
for i in nums:
	print(i, end=" ")

print()
