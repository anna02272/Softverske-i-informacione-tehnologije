#program poredi dva broje i prikazuje rezultat

a, b = eval(input("Unesite dva broja"))

if a > b:
	print("a je vece od b", a ,b)
elif a < b:
	print("a je manje od b", a, b)
else:
	print("a je jednako b", a , b)