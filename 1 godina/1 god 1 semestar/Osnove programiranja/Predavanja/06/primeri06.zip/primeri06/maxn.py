# program: maxn.py
# Nalazi maksimum serije brojeva

def main():
    n = eval(raw_input("Koliko ima brojeva? "))
    max = eval(raw_input("Unesite broj >> "))

    for i in range(n-1): 
        x = eval(raw_input("Unesite broj >> "))
        if x > max:
            max = x

    print "Najveci broj je", max


main()
