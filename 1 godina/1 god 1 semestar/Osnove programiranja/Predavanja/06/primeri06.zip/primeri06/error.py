import math

try:
	a = eval(input("Unesite neki broj "))

	koren = math.sqrt(a)

	print("Koren je", koren)

except ValueError:
	print("Desila se greska kod racunanja korena")