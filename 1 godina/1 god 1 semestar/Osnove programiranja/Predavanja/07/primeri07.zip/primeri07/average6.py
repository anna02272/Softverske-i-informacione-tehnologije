# average6.py

def main():
    fileName = input("Ime fajla sa brojevima? ")
    infile = open(fileName,'r')
    sum = 0.0
    count = 0
    line = infile.readline()
    while line != "":
        sum = sum + eval(line)
        count = count + 1
        line = infile.readline()
    print("\nProsek je", sum / count)

main()
