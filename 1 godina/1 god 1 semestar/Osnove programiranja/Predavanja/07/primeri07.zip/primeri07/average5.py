# average5.py

def main():
    fileName = input("Ime fajla sa brojevima? ")
    infile = open(fileName,'r')
    sum = 0.0
    count = 0
    for line in infile:
        sum = sum + eval(line)
        count = count + 1
    print("\nProsek je", sum / count)

main()
