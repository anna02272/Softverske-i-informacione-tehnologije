#primer rada while petlje

i = 0;

while i <= 10:
	print(i)
	i = i + 1


print("ispis unazad")
i = 10

while i >= 0:
	print(i)
	i = i - 1