# average3.py

def main():
    sum = 0.0
    count = 0
    x = eval(input("Unesite broj (negativan za kraj) >> "))
    while x >= 0:
        sum = sum + x
        count = count + 1
        x = eval(input("EUnesite broj (negativan za kraj) >> "))
    print("\nProsek je", sum / count)

main()
