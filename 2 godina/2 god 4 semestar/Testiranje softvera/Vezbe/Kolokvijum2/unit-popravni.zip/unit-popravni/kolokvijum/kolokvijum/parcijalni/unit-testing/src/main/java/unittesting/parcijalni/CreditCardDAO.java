package unittesting.parcijalni;

import java.util.HashMap;

public class CreditCardDAO {

	private HashMap<Integer, CreditCard> creditCardStorage;

	public CreditCardDAO() {
		super();
	}

	public CreditCard findByCreditCardNumber(Long creditCardNumber) {
		return null;
	}
}
