package unittesting.parcijalni;

public class CreditCardService {

	private CreditCardDAO creditCardDAO;	
	
	/**
	 * Metoda koja racuna novo stanje na racunu
	 * @param balanceOnAccount stanje na kreditnoj kartici
	 * @param amount suma novca koja se prenosi transakcijom
	 * @param maxAmount maksimalan iznos koji moze da se podigne sa kartice
	 * @param cardType tip kartice-debitna, kreditna
	 */
	public static double calculateNewBalance(double balanceOnAccount, double amount, double maxAmount, String cardType) {
	    if (cardType.equalsIgnoreCase("debit")) {
	        if (amount > balanceOnAccount) {
	            System.out.println("Insufficient balance!");
	            return balanceOnAccount;
	        }
	        return balanceOnAccount - amount;
	    } else if (cardType.equalsIgnoreCase("credit")) {
	        if (amount + balanceOnAccount > maxAmount) {
	            System.out.println("Transaction amount exceeds maximum limit!");
	            return balanceOnAccount;
	        }
	        return balanceOnAccount + amount;
	    } else {
	        System.out.println("Invalid transaction!");
	        return balanceOnAccount;
	    }
	}
	
		
	/**
	 * Metoda izvrsava novcanu transakciju 
	 * @param balanceOnAccount stanje na kreditnoj kartici
	 * @param amount suma novca koja se prenosi transakcijom
	 * @param payout true ako je dozvoljena transakcija, false ako nije dozvoljena
	 * @param minimum minimalna suma koja moze da bude na racunu
	 * @param creditCardNumber broj kreditne kartice
	 * */
	public String performTransaction(double balanceOnAccount, double amount, boolean payout, double minimum, long creditCardNumber, int pin) {
		CreditCard creditCard = creditCardDAO.findByCreditCardNumber(creditCardNumber);
		if (creditCard.getPin() != pin) {
			return "Invalid credit card or PIN.";
		}
		
	    if (balanceOnAccount < amount) {
	        return "Insufficient balance!";
	    }

	    if (!payout) {
	        return "Payout not allowed.";
	    }

	    if (balanceOnAccount - amount < minimum) {
	        return "Transaction not allowed. Minimum balance requirement not met.";
	    }
		
	    // Proceed with the transaction
		return "Transaction successful!";
	}
	
	
	/**
	 * Metoda proverava da li je transakcija validna. 
	 * 
	 * Ukoliko kreditna kartica ne postoji u sistemu, baca NullPointerException()
	 * 
	 * Ukoliko PIN nije ispavan i broj pokušaja je manji od 3, vraća False
	 * 
	 * Ukoliko PIN nije isparav i broj pokušaja je veći od 3, baca False
	 * 
	 * Ukoliko je PIN isparan a kolicina novca koja se podize sa racuna veca od limita, vraca False
	 * 
	 * Ukoliko je PIN isparan a kolicina novca koja se podize sa racuna manja od limita, vraca True
	 */
	public boolean validateTransaction(Long creditCardNumber, int PIN, double amount) {

		CreditCard creditCard = creditCardDAO.findByCreditCardNumber(creditCardNumber);
		boolean isCardValid = creditCard.getPin() == PIN && creditCard.getNumOfTries() < 3;
		boolean isTransactionValid = amount < creditCard.getLimit();

		if (isCardValid && isTransactionValid) {
			return true;
		} 

		return false;
	}
	

	public void setCreditCardDAO(CreditCardDAO creditCardDAO) {
		this.creditCardDAO = creditCardDAO;
	}

}
