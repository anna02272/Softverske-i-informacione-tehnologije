package com.ftn.OWPVezba3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OwpVezba3Application {

	public static void main(String[] args) {
		SpringApplication.run(OwpVezba3Application.class, args);
	}

}
