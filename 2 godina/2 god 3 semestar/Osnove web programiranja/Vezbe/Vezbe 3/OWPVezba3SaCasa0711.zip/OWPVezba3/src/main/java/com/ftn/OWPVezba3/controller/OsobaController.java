package com.ftn.OWPVezba3.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.ServletContextAware;

import com.ftn.OWPVezba3.bean.Osoba;

@Controller
@RequestMapping("osoba")
public class OsobaController implements ServletContextAware {
	
	public static final String OSOBA_KEY = "osobe";
	
	@Autowired
	private ServletContext servletContext;
	
	@Override
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}
	
	@PostConstruct
	public void init() {
		List<Osoba> osobe = new ArrayList<>();
		servletContext.setAttribute(OSOBA_KEY, osobe);
	}

	@GetMapping
	public String getForma() {
		return "./dodaj-osobu.html";
	}
	
	@SuppressWarnings("unchecked")
	@PostMapping(value = "/dodajOsobu")
	@ResponseBody
	public String dodajOsobu(@ModelAttribute Osoba osoba) {
		List<Osoba> osobe = (List<Osoba>) servletContext.getAttribute(OSOBA_KEY);
		osobe.add(osoba);
		
		String htmlZaPrikaz = 
				"<html>"
					+ "<head>"
						+ "<title>Osoba</title>"
					+ "</head>"
					+ "<body>"
						+ "IME:&nbsp;" + osoba.getIme()
						+ "<br/>"
						+ "PREZIME:&nbsp;" + osoba.getPrezime()
						+ "<br/>"
						+ "<a href=\"osoba\">Vrati se na unos</a>"
					+ "</body>"
				+ "</html>";
		
		return htmlZaPrikaz;
	}

	
	
}
